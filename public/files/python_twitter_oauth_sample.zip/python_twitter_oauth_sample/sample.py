# sudo easy_install python-twitter  # http://code.google.com/p/python-twitter/
# sudo easy_install simplejson      # http://pypi.python.org/pypi/simplejson/

# Fill in TWITTER_CONSUMER_KEY, TWITTER_CONSUMER_SECRET. Get these values from
# your app's twitter account https://twitter.com/oauth_clients

TWITTER_CONSUMER_KEY    = "FILL_ME_IN"
TWITTER_CONSUMER_SECRET = "FILL_ME_IN"

# http://code.google.com/p/oauth-python-twitter
from twitter_oauth import OAuthApi
import time

if __name__ == "__main__":
    twitter = OAuthApi(TWITTER_CONSUMER_KEY, TWITTER_CONSUMER_SECRET)
    request_token = twitter.getRequestToken()
    twitter_oauth_url = twitter.getAuthorizationURL(request_token)

    print "Visit this url in browser and authenticate a user"
    print twitter_oauth_url
    time.sleep(60)

    # After successfully auth's
    twitter = OAuthApi(TWITTER_CONSUMER_KEY, TWITTER_CONSUMER_SECRET, request_token)

    # returns python-twitter User object http://static.unto.net/python-twitter/0.6/doc/twitter.html#User
    user = twitter.GetUserInfo()
